<?php
include_once('../config/sessao.php');
include_once('layout/head.php');
include_once('layout/header.php');
?>
<body class="bg-light">



<?php include_once('layout/footer.php') ?>