
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"> </script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"> </script>

<!-- Swiper JS -->
<script src="https://kit.fontawesome.com/7bf6493d81.js" crossorigin="anonymous"></script>

<!-- JavaScript -->
<!-- Inclua o jQuery (dependência do Inputmask) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Inclua a biblioteca Inputmask -->
<script src="/caminho/para/inputmask.min.js"></script>

<script src="../js/sidebar.js"></script>
<script src="../js/formMask.js"></script>

</body>

</html>